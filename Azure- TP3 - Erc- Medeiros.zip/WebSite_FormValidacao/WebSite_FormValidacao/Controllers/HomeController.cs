﻿using System.Web.Mvc;
using WebSite_FormValidacao.Models;

namespace WebSite_FormValidacao.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Questionario()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Questionario(QuestionarioModel resposta)
        {
            try
            {
                return RedirectToAction("Obrigado");
            }
            catch
            {
                return View();
            }
        }

        // GET: /Home/Obrigado
        public ActionResult Obrigado()
        {
            return View();
        }
    }
}
